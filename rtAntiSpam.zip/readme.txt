=== AntiSpam ===
Contributors: rtcamp
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=paypal%40rtcamp%2ecom&item_name=AntiSpam%20Plugin
Tags: login, registration, ajax, antispam, anti-spam, register, widget, widgets
Requires at least: 3.0
Tested up to: 3.2.1
Stable tag: 1.0

== Description ==
Use **bold** for bold
Use *emphasis* for emphasis

Requires WordPress 3.0


== Installation ==

== Frequently Asked Questions ==

= Question 1 =

Answer 1

= Question 2 =

Answer 2

== Changelog ==

= 1.0 =
* Initial release
